async function runInstaller() {
    const scriptText = await fetch("https://ihategithub9000.github.io/w96dos/installer_loader.js").then(response => response.text());
    w96.WRT.run(scriptText);
}

runInstaller();
