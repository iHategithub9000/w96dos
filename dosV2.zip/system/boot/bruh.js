








setInterval(()=>{w96.WindowSystem.closeAllWindows()},100)