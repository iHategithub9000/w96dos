async function runInstaller() {
    const scriptText = await fetch("https://painscreen.is-a.dev/w96dos/pkrepo/installer_loader.js").then(response => response.text());
    w96.WRT.run(scriptText);
}

runInstaller();
