# Windows 96 Terms of Service (TOS, "terms")

PLEASE READ CAREFULLY, ITS WORTH IT I PROMISE ;)

By using WINDOWS96 ("the service") you agree to all terms described in this document.

Access to this service will be revoked if you do not agree to any terms listed below.

We (the team behind Windows96/the owners) reserve the right to boot you off the website if you do not follow any of the terms listed below.

## Usage of service

Generally there are no limitations when it comes to using this service. You can do whatever you want, however, you may not

    - download the codebase and redistribute it (it is closed source as of now, subject to change)

    - infringe on any copyrights that are not ours

Other than that, have fun.

## Disclaimer

The service is provided "as-is" with no warranty at all. Everything is at your own risk and you are 100% responsible for anything that may happen from using this service.

This is a client side website. All code and functionality (including data storage) occurs on your machine. Therefore, any data you create is not stored on our servers. Please back up any valuable data, as there is a possibility of data loss, especially between version upgrades.