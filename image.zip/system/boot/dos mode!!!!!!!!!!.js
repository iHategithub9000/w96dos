w96.evt.sys.on("init-complete", async () => {
  document.querySelectorAll("*").forEach((e)=>{e.style.filter="saturate(9999999999999999999999999%)"})
  w96.state.processes.find(e => e && e.title === "shell36").terminate();
  w96.sys.execCmd("terminal")
});
