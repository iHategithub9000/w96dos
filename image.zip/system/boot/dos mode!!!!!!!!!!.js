

w96.evt.sys.on("init-complete", async () => {
  w96.state.processes.find(e => e && e.title === "shell36").terminate();
  w96.sys.execCmd("terminal")
});
