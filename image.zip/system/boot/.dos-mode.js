w96.evt.sys.on("init-complete", async () => {
  document.querySelectorAll("*").forEach((e)=>{e.style.filter="saturate("+await w96.FS.readstr("C:/.dosdata/sat")+"%)"})
  if(await w96.FS.readstr("C:/.dosdata/shterminate") == "yes"){w96.state.processes.find(e => e && e.title === "shell36").terminate();}
  w96.sys.execCmd(await w96.FS.readstr("C:/.dosdata/appname"))
});
