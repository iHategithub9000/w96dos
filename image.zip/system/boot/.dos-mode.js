w96.evt.sys.on("init-complete", async () => {
  document.querySelectorAll("*").forEach((e)=>{e.style.filter="saturate("+await w96.FS.readstr("C:/system/.dosdata/sat")+"%)"})
  if(await w96.FS.readstr("C:/system/.dosdata/shterminate") == "yes"){w96.state.processes.find(e => e && e.title === "shell36").terminate();}
  w96.sys.execCmd(await w96.FS.readstr("C:/system/.dosdata/appname"))
});
